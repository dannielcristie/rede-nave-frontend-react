import { useState } from "react";
import { Navbar } from "./components/navbar";
import { About } from "./components/about";
import { CoursesCarousel } from "./components/courses-carousel";
import { EventsCarousel } from "./components/events-carousel";
import { Contact } from "./components/contact";
import { Footer } from "./components/footer";
import { Login } from "./components/login";
import { Sidebar } from "./components/sidebar";
import { StudentDashboard } from "./components/student/dashboard";
import { CoursePlayer } from "./components/student/course-player";
import { TeacherDashboard } from "./components/teacher/dashboard";
import { AdminDashboard } from "./components/admin/dashboard";
import { ProfilePage } from "./components/profile-page";
import { StudentMyCourses } from "./components/student/my-courses";
import { StudentEvents } from "./components/student/events";
import { StudentCertificates } from "./components/student/certificates";
import { TeacherClasses } from "./components/teacher/classes";
import { TeacherStudents } from "./components/teacher/students";
import { TeacherReports } from "./components/teacher/reports";
import { AdminStats } from "./components/admin/stats";
import { AdminUsers } from "./components/admin/users";
import { AdminCourses } from "./components/admin/courses";
import { AdminSettings } from "./components/admin/settings";
import "bootstrap@5.3.2/dist/css/bootstrap.min.css";
import "./styles/bootstrap-custom.css";

type UserRole = "student" | "teacher" | "admin" | null;
type Page = "landing" | "login" | "dashboard" | "my-courses" | "events" | "certificates" | "profile" | "classes" | "students" | "reports" | "stats" | "users" | "courses" | "settings" | "course-player";

export default function App() {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [currentPage, setCurrentPage] = useState<Page>("landing");
  const [coursePlayerData, setCoursePlayerData] = useState<any>(null);

  const handleLogin = (role: UserRole) => {
    setUserRole(role);
    setCurrentPage("dashboard");
  };

  const handleLogout = () => {
    setUserRole(null);
    setCurrentPage("landing");
  };

  const handleNavigate = (page: string, data?: any) => {
    if (page === "course-player") {
      setCoursePlayerData(data);
    }
    setCurrentPage(page as Page);
  };

  // Landing Page
  if (currentPage === "landing") {
    return (
      <div className="min-vh-100">
        <Navbar onLoginClick={() => setCurrentPage("login")} />
        <main>
          <CoursesCarousel />
          <EventsCarousel />
          <About />
          <Contact />
        </main>
        <Footer />
      </div>
    );
  }

  // Login Page
  if (currentPage === "login") {
    return <Login onLogin={handleLogin} />;
  }

  // Course Player (full screen, no sidebar)
  if (currentPage === "course-player" && userRole === "student") {
    return (
      <CoursePlayer
        courseId={coursePlayerData?.courseId || 1}
        onBack={() => setCurrentPage("dashboard")}
      />
    );
  }

  // Authenticated Pages with Sidebar
  return (
    <div className="d-flex min-vh-100" style={{ backgroundColor: '#f8f9fa' }}>
      <Sidebar
        role={userRole!}
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
      />
      <main className="flex-fill main-with-sidebar">
        {/* Student Pages */}
        {userRole === "student" && currentPage === "dashboard" && (
          <StudentDashboard onNavigate={handleNavigate} />
        )}
        {userRole === "student" && currentPage === "my-courses" && (
          <StudentMyCourses onNavigate={handleNavigate} />
        )}
        {userRole === "student" && currentPage === "events" && (
          <StudentEvents />
        )}
        {userRole === "student" && currentPage === "certificates" && (
          <StudentCertificates />
        )}
        
        {/* Teacher Pages */}
        {userRole === "teacher" && currentPage === "dashboard" && (
          <TeacherDashboard onNavigate={handleNavigate} />
        )}
        {userRole === "teacher" && currentPage === "classes" && (
          <TeacherClasses />
        )}
        {userRole === "teacher" && currentPage === "students" && (
          <TeacherStudents />
        )}
        {userRole === "teacher" && currentPage === "reports" && (
          <TeacherReports />
        )}
        
        {/* Admin Pages */}
        {userRole === "admin" && currentPage === "dashboard" && (
          <AdminDashboard onNavigate={handleNavigate} />
        )}
        {userRole === "admin" && currentPage === "stats" && (
          <AdminStats />
        )}
        {userRole === "admin" && currentPage === "users" && (
          <AdminUsers />
        )}
        {userRole === "admin" && currentPage === "courses" && (
          <AdminCourses />
        )}
        {userRole === "admin" && currentPage === "settings" && (
          <AdminSettings />
        )}

        {/* Profile Page (comum a todos) */}
        {currentPage === "profile" && (
          <ProfilePage userRole={userRole!} />
        )}

        {/* Placeholder for other pages */}
        {![
          "dashboard", "course-player", "my-courses", "events", "certificates", "profile",
          "classes", "students", "reports", "stats", "users", "courses", "settings"
        ].includes(currentPage) && (
          <div className="p-4">
            <div className="bg-white rounded border border-2 border-dashed p-5 text-center" style={{ borderColor: '#dee2e6' }}>
              <p className="text-muted mb-0">
                Página "{currentPage}" em desenvolvimento
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}