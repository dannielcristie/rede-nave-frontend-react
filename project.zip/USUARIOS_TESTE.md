# Usuários de Teste - Rede Nave

## 👩‍🎓 Aluna (Student)
- **Email:** aluna@redenave.com
- **Senha:** aluna123
- **Nome:** Maria Silva
- **Acesso:** Cursos, Eventos, Certificados, Perfil

## 👩‍🏫 Professora (Teacher)
- **Email:** professora@redenave.com
- **Senha:** prof123
- **Nome:** Ana Santos
- **Acesso:** Turmas, Alunas, Relatórios, Perfil

## ⚙️ Administrador (Admin)
- **Email:** admin@redenave.com
- **Senha:** admin123
- **Nome:** Administrador
- **Acesso:** Dashboard, Estatísticas, Usuários, Cursos, Configurações, Perfil

---

## Acesso Rápido

Na tela de login, há um painel com botões de acesso rápido para cada tipo de usuário. Basta clicar no botão correspondente para fazer login automaticamente.

## Estrutura da Plataforma

### Páginas da Aluna:
- **Dashboard:** Visão geral dos cursos em andamento
- **Meus Cursos:** Lista completa de cursos (em andamento e concluídos)
- **Eventos:** Eventos disponíveis e anteriores
- **Certificados:** Certificados dos cursos concluídos
- **Perfil:** Gerenciar informações pessoais

### Páginas da Professora:
- **Dashboard:** Visão geral das turmas e estatísticas
- **Minhas Turmas:** Gerenciar turmas ativas e concluídas
- **Minhas Alunas:** Lista de alunas com progresso e desempenho
- **Relatórios:** Análise de desempenho e estatísticas
- **Perfil:** Gerenciar informações pessoais

### Páginas do Admin:
- **Dashboard:** Visão geral da plataforma
- **Estatísticas:** Métricas detalhadas de crescimento
- **Usuários:** Gerenciar alunas, professoras e admins
- **Cursos:** Gerenciar cursos da plataforma
- **Configurações:** Configurações gerais, email, notificações, etc.
- **Perfil:** Gerenciar informações pessoais

## Tecnologias Utilizadas

- **React** com TypeScript
- **Bootstrap 5.3.2** para estilização
- **Lucide React** para ícones
- **CSS Customizado** com variáveis Bootstrap

## Paleta de Cores

- **Roxo Primário:** #6a2e99
- **Roxo Acentuado:** #8e44ad
- **Verde Acentuado:** #9acd32
