import { useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Info, Lock, Mail } from "lucide-react";

interface LoginProps {
  onLogin?: (role: "student" | "teacher" | "admin") => void;
}

// Usuários de teste pré-definidos
const TEST_USERS = {
  student: { email: "aluna@redenave.com", password: "aluna123", name: "Maria Silva" },
  teacher: { email: "professora@redenave.com", password: "prof123", name: "Ana Santos" },
  admin: { email: "admin@redenave.com", password: "admin123", name: "Administrador" }
};

export function Login({ onLogin }: LoginProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showHelper, setShowHelper] = useState(true);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Verificar credenciais
    if (email === TEST_USERS.student.email && password === TEST_USERS.student.password) {
      onLogin?.("student");
    } else if (email === TEST_USERS.teacher.email && password === TEST_USERS.teacher.password) {
      onLogin?.("teacher");
    } else if (email === TEST_USERS.admin.email && password === TEST_USERS.admin.password) {
      onLogin?.("admin");
    } else {
      alert("Credenciais inválidas! Use um dos usuários de teste.");
    }
  };

  const handleQuickLogin = (role: "student" | "teacher" | "admin") => {
    setEmail(TEST_USERS[role].email);
    setPassword(TEST_USERS[role].password);
    setTimeout(() => onLogin?.(role), 100);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    // Registrar como aluna por padrão
    onLogin?.("student");
  };

  return (
    <div className="min-vh-100 position-relative d-flex align-items-center justify-content-center p-4">
      {/* Background Image */}
      <div className="position-absolute top-0 start-0 end-0 bottom-0" style={{ zIndex: 0 }}>
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1646295404846-658322e343e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21lbiUyMGVtcG93ZXJtZW50JTIwYnVzaW5lc3N8ZW58MXx8fHwxNzYzMzk0MzE0fDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Background"
          className="w-100 h-100 img-cover"
        />
        <div className="position-absolute top-0 start-0 end-0 bottom-0 gradient-overlay-purple"></div>
      </div>

      {/* Content */}
      <div className="position-relative container" style={{ zIndex: 10, maxWidth: '900px' }}>
        <div className="row g-4">
          {/* Helper Box - Cola para testes */}
          {showHelper && (
            <div className="col-12">
              <div className="login-helper rounded-3 p-3 shadow-sm">
                <div className="d-flex align-items-start justify-content-between mb-2">
                  <div className="d-flex align-items-center gap-2">
                    <Info size={20} className="text-primary-purple" />
                    <h6 className="mb-0 fw-bold">Usuários de Teste - Acesso Rápido</h6>
                  </div>
                  <button 
                    onClick={() => setShowHelper(false)}
                    className="btn-close"
                    aria-label="Fechar"
                  ></button>
                </div>
                
                <div className="row g-2">
                  <div className="col-md-4">
                    <button
                      onClick={() => handleQuickLogin("student")}
                      className="btn btn-sm btn-outline-primary w-100 text-start"
                    >
                      <div className="fw-bold">👩‍🎓 Aluna</div>
                      <small className="text-muted d-block">{TEST_USERS.student.email}</small>
                    </button>
                  </div>
                  <div className="col-md-4">
                    <button
                      onClick={() => handleQuickLogin("teacher")}
                      className="btn btn-sm btn-outline-primary w-100 text-start"
                    >
                      <div className="fw-bold">👩‍🏫 Professora</div>
                      <small className="text-muted d-block">{TEST_USERS.teacher.email}</small>
                    </button>
                  </div>
                  <div className="col-md-4">
                    <button
                      onClick={() => handleQuickLogin("admin")}
                      className="btn btn-sm btn-outline-primary w-100 text-start"
                    >
                      <div className="fw-bold">⚙️ Admin</div>
                      <small className="text-muted d-block">{TEST_USERS.admin.email}</small>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Login Card */}
          <div className="col-12">
            <div className="card shadow-lg border-0">
              <div className="card-body p-4 p-md-5">
                {/* Tabs */}
                <ul className="nav nav-tabs mb-4 border-0" role="tablist">
                  <li className="nav-item flex-fill" role="presentation">
                    <button
                      className={`nav-link w-100 ${activeTab === "login" ? "active" : ""}`}
                      onClick={() => setActiveTab("login")}
                      type="button"
                    >
                      Entrar
                    </button>
                  </li>
                  <li className="nav-item flex-fill" role="presentation">
                    <button
                      className={`nav-link w-100 ${activeTab === "register" ? "active" : ""}`}
                      onClick={() => setActiveTab("register")}
                      type="button"
                    >
                      Cadastrar
                    </button>
                  </li>
                </ul>

                {/* Login Form */}
                {activeTab === "login" && (
                  <form onSubmit={handleLogin}>
                    <div className="text-center mb-4">
                      <h2 className="mb-2">Bem-vinda de volta!</h2>
                      <p className="text-muted">Entre com suas credenciais</p>
                    </div>

                    <div className="mb-3">
                      <label htmlFor="email" className="form-label">Email</label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <Mail size={18} />
                        </span>
                        <input
                          type="email"
                          className="form-control"
                          id="email"
                          placeholder="seu@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div className="mb-3">
                      <label htmlFor="password" className="form-label">Senha</label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <Lock size={18} />
                        </span>
                        <input
                          type="password"
                          className="form-control"
                          id="password"
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div className="d-flex justify-content-between align-items-center mb-4">
                      <div className="form-check">
                        <input type="checkbox" className="form-check-input" id="remember" />
                        <label className="form-check-label" htmlFor="remember">
                          Lembrar-me
                        </label>
                      </div>
                      <a href="#" className="text-primary-purple text-decoration-none">
                        Esqueci a senha
                      </a>
                    </div>

                    <button type="submit" className="btn btn-primary w-100 py-2 mb-3">
                      Entrar
                    </button>

                    <p className="text-center text-muted mb-0">
                      Não tem uma conta?{" "}
                      <button
                        type="button"
                        onClick={() => setActiveTab("register")}
                        className="btn btn-link p-0 text-primary-purple text-decoration-none"
                      >
                        Cadastre-se
                      </button>
                    </p>
                  </form>
                )}

                {/* Register Form */}
                {activeTab === "register" && (
                  <form onSubmit={handleRegister}>
                    <div className="text-center mb-4">
                      <h2 className="mb-2">Crie sua conta</h2>
                      <p className="text-muted">Comece sua jornada de aprendizado</p>
                    </div>

                    <div className="mb-3">
                      <label htmlFor="reg-name" className="form-label">Nome Completo</label>
                      <input
                        type="text"
                        className="form-control"
                        id="reg-name"
                        placeholder="Maria Silva"
                        required
                      />
                    </div>

                    <div className="mb-3">
                      <label htmlFor="reg-email" className="form-label">Email</label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <Mail size={18} />
                        </span>
                        <input
                          type="email"
                          className="form-control"
                          id="reg-email"
                          placeholder="seu@email.com"
                          required
                        />
                      </div>
                    </div>

                    <div className="mb-3">
                      <label htmlFor="reg-password" className="form-label">Senha</label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <Lock size={18} />
                        </span>
                        <input
                          type="password"
                          className="form-control"
                          id="reg-password"
                          placeholder="••••••••"
                          required
                        />
                      </div>
                    </div>

                    <div className="mb-4">
                      <label htmlFor="reg-confirm" className="form-label">Confirmar Senha</label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <Lock size={18} />
                        </span>
                        <input
                          type="password"
                          className="form-control"
                          id="reg-confirm"
                          placeholder="••••••••"
                          required
                        />
                      </div>
                    </div>

                    <button type="submit" className="btn btn-primary w-100 py-2 mb-3">
                      Cadastrar
                    </button>

                    <p className="text-center text-muted mb-0">
                      Já tem uma conta?{" "}
                      <button
                        type="button"
                        onClick={() => setActiveTab("login")}
                        className="btn btn-link p-0 text-primary-purple text-decoration-none"
                      >
                        Entrar
                      </button>
                    </p>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
